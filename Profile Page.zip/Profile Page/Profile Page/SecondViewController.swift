//
//  SecondViewController.swift
//  Profile Page
//
//  Created by Andrew Simon on 11/3/20.
//  Copyright © 2020 Andrew Simon. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController
{    
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myTextField: UITextField!
    
    var fieldName: String?
    var myText: String?
    var myTextFieldUpdated: ((_ newText: String) -> Void)?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        myLabel.text = fieldName
        myTextField.text = myText
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func update(_ sender: Any)
    {
        myTextFieldUpdated?(myTextField.text!)
        navigationController?.popViewController(animated: true)
    }
}
